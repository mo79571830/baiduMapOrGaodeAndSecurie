//
//  LockViewController.m
//  FFCBW-2016
//
//  Created by 王祺祺 on 16/3/29.
//  Copyright © 2016年 com.audionew.sdr. All rights reserved.
//

#import "LocViewController.h"
#import "HVWLocView.h"
#import "GlobleChangeViewController.h"
@interface LocViewController ()<HVWLocViewDelegate>
{
    NSInteger num ;
    NSString * num1;
}
@property(nonatomic,strong)UILabel * testLabel;
@end

@implementation LocViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Home_refresh_b"]];
    HVWLocView * hvV = [[HVWLocView alloc]initWithFrame:CGRectMake(0, 150, self.view.frame.size.width, self.view.frame.size.height - 240)];
    hvV.delegate = self;
    num = 1;
    [self.view addSubview:hvV];
   self.testLabel = [[UILabel alloc]initWithFrame:CGRectMake(50, 80, self.view.frame.size.width - 100, 30)];
    self.testLabel.textAlignment = NSTextAlignmentCenter;
    self.testLabel.textColor = [UIColor redColor];
    [self.view addSubview:self.testLabel];
    if(self.isDoor != YES || self.isLogin == YES)
    {
        UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 50, 60, 30)];
        [btn setTitle:@"取消" forState:UIControlStateNormal];
        
        [btn addTarget:self action:@selector(cancelClick) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn];

    }
    
}
-(void)cancelClick
{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
/** 设置状态栏样式 */
- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}
#pragma mark HVWLocViewDelegate
- (void)hvwLockView:(HVWLocView *)hvwLockView didFinishedWithPath:(NSString *)path {
    NSLog(@"手势解锁的输出序列：%@", path);
    
        if(self.isOn == YES)
        {//设置手势密码
            if(path.length < 4)
            {
                self.testLabel.text = @"请输入多余四个按钮";
            }
            else
            {
                if(num == 1)
                {
                    NSLog(@"第一次测试");
                    num1 = path;
                    num = 2;
                    self.testLabel.text = @"请再输入一次";
                }
                else
                {
                    NSLog(@"第二次");
                    if([num1 isEqualToString:path])
                    {
                        self.testLabel.text = @"输入正确";
                        
                        [self dismissViewControllerAnimated:YES completion:nil];
                    }
                    else
                    {
                        self.testLabel.text = @"输入失败";
                    }
                }
                

            }
            
        }
        else
        {//验证图形密码
            if([self.gesString isEqualToString:path])
            {
                [self dismissViewControllerAnimated:YES completion:nil];
            }
            else
            {
                self.testLabel.text = @"输入错误";
            }
        }
       
        

  
    
}


@end
