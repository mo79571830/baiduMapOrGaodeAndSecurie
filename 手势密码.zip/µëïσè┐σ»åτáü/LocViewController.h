//
//  LockViewController.h
//  FFCBW-2016
//
//  Created by 王祺祺 on 16/3/29.
//  Copyright © 2016年 com.audionew.sdr. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LocViewController : UIViewController
@property(nonatomic,assign)BOOL isOn;
@property(nonatomic,copy)NSString * gesString;
@property(nonatomic,assign)BOOL isDoor;//判断是否是主界面
@property(nonatomic,assign)BOOL isLogin;//判断是否是登陆界面
@end
