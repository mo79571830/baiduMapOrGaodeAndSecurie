//
//  HVWLockButton.h
//  HVWLockView
//
//  Created by hellovoidworld on 15/1/12.
//  Copyright (c) 2015年 hellovoidworld. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HVWLocButton : UIButton

/** 可触碰范围 */
@property(nonatomic, assign) CGRect touchFrame;

@end
